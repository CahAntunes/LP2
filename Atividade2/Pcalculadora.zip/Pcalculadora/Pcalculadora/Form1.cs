﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lblNumero2_Click(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();

            txtNumero1.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void lblNumero1_Click(object sender, EventArgs e)
        {

        }

        private void btnSomar_Click(object sender, EventArgs e)
        {
            double numero1, numero2, resultado;

            if (Double.TryParse(txtNumero1.Text, out numero1) &&
                Double.TryParse(txtNumero2.Text, out numero2))
            {
                resultado = numero1 + numero2; 
                txtResultado.Text = resultado.ToString(); 
            }
            else
                MessageBox.Show("Valores Inválidos");
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            double numero1, numero2, resultado;

            if (Double.TryParse(txtNumero1.Text, out numero1) &&
                Double.TryParse(txtNumero2.Text, out numero2))
            {
                resultado = numero1 - numero2;
                txtResultado.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Valores Inválidos");
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            double numero1, numero2, resultado;

            if (Double.TryParse(txtNumero1.Text, out numero1) &&
                Double.TryParse(txtNumero2.Text, out numero2))
            {
                resultado = numero1 * numero2;
                txtResultado.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Valores Inválidos");
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            double numero1, numero2, resultado;

            if (Double.TryParse(txtNumero1.Text, out numero1) &&
                Double.TryParse(txtNumero2.Text, out numero2))
            {
                if (numero2 != 0)
                {
                    resultado = numero1 / numero2;
                    txtResultado.Text = resultado.ToString();
                }
                else
                {
                    MessageBox.Show("Divisão Inválida");
                }
            }
            else
                MessageBox.Show("Valores Inválidos");
        }


       
       
    }
}
