﻿using System;
using System.Windows.Forms;

namespace Ptrinagulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double A, B, C;

            txtValorA.Text = txtValorA.Text.Replace(".", ",");
            txtValorB.Text = txtValorB.Text.Replace(".", ",");
            txtValorC.Text = txtValorC.Text.Replace(".", ",");

            if (!Double.TryParse(txtValorA.Text, out A) ||
                !Double.TryParse(txtValorB.Text, out B) ||
                !Double.TryParse(txtValorC.Text, out C))
            {
                MessageBox.Show("Valores devem ser númericos!");
            }
            else
            {
                if (A < (B + C) && A > Math.Abs(B - C) && B < (A + C) &&
                    B > Math.Abs(A - C) && C < (A + B) && C > Math.Abs(A - B))
                {
                    if (A == B && B == C)
                    {
                        MessageBox.Show("O triângulo é equilátero!");
                    }
                    else
                    {
                        if (A == B || A == C || C == B)
                        {
                            MessageBox.Show("O triângulo é isósceles!");
                        }
                        else
                        {
                            MessageBox.Show("O triângulo é escaleno!"); 
                        }
                        
                    }

                }
                else
                {
                    MessageBox.Show("Não é possível formar um triâgulo!");
                }


            }

        }

        private void bntLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Clear();
            txtValorB.Clear();
            txtValorC.Clear();    
        }
    }
}
