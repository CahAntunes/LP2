﻿namespace Pclasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bntInstHor = new System.Windows.Forms.Button();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalHora = new System.Windows.Forms.Label();
            this.lblNumHoras = new System.Windows.Forms.Label();
            this.lblDataEntEmp = new System.Windows.Forms.Label();
            this.lblDiasFalta = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalHora = new System.Windows.Forms.TextBox();
            this.txtNumHora = new System.Windows.Forms.TextBox();
            this.txtDataEntEmp = new System.Windows.Forms.TextBox();
            this.txtDiasFaltas = new System.Windows.Forms.TextBox();
            this.gbxTrabHomeOf = new System.Windows.Forms.GroupBox();
            this.rbntNao = new System.Windows.Forms.RadioButton();
            this.rbtnSim = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.gbxTrabHomeOf.SuspendLayout();
            this.SuspendLayout();
            // 
            // bntInstHor
            // 
            this.bntInstHor.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntInstHor.Location = new System.Drawing.Point(480, 423);
            this.bntInstHor.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bntInstHor.Name = "bntInstHor";
            this.bntInstHor.Size = new System.Drawing.Size(270, 48);
            this.bntInstHor.TabIndex = 0;
            this.bntInstHor.Text = "Instanciar Horista";
            this.bntInstHor.UseVisualStyleBackColor = true;
            this.bntInstHor.Click += new System.EventHandler(this.bntInstHor_Click);
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMatricula.Location = new System.Drawing.Point(43, 70);
            this.lblMatricula.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(119, 29);
            this.lblMatricula.TabIndex = 1;
            this.lblMatricula.Text = "Matrícula";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(43, 126);
            this.lblNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(79, 29);
            this.lblNome.TabIndex = 2;
            this.lblNome.Text = "Nome";
            // 
            // lblSalHora
            // 
            this.lblSalHora.AutoSize = true;
            this.lblSalHora.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalHora.Location = new System.Drawing.Point(43, 180);
            this.lblSalHora.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalHora.Name = "lblSalHora";
            this.lblSalHora.Size = new System.Drawing.Size(200, 29);
            this.lblSalHora.TabIndex = 3;
            this.lblSalHora.Text = "Salário por Hora";
            // 
            // lblNumHoras
            // 
            this.lblNumHoras.AutoSize = true;
            this.lblNumHoras.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumHoras.Location = new System.Drawing.Point(43, 246);
            this.lblNumHoras.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNumHoras.Name = "lblNumHoras";
            this.lblNumHoras.Size = new System.Drawing.Size(212, 29);
            this.lblNumHoras.TabIndex = 4;
            this.lblNumHoras.Text = "Número de Horas";
            // 
            // lblDataEntEmp
            // 
            this.lblDataEntEmp.AutoSize = true;
            this.lblDataEntEmp.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataEntEmp.Location = new System.Drawing.Point(43, 305);
            this.lblDataEntEmp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDataEntEmp.Name = "lblDataEntEmp";
            this.lblDataEntEmp.Size = new System.Drawing.Size(302, 29);
            this.lblDataEntEmp.TabIndex = 5;
            this.lblDataEntEmp.Text = "Data Entrada na Empresa";
            // 
            // lblDiasFalta
            // 
            this.lblDiasFalta.AutoSize = true;
            this.lblDiasFalta.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiasFalta.Location = new System.Drawing.Point(43, 363);
            this.lblDiasFalta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDiasFalta.Name = "lblDiasFalta";
            this.lblDiasFalta.Size = new System.Drawing.Size(174, 29);
            this.lblDiasFalta.TabIndex = 6;
            this.lblDiasFalta.Text = "Dias de Faltas";
            // 
            // txtMatricula
            // 
            this.txtMatricula.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMatricula.Location = new System.Drawing.Point(191, 69);
            this.txtMatricula.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(132, 30);
            this.txtMatricula.TabIndex = 7;
            // 
            // txtNome
            // 
            this.txtNome.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNome.Location = new System.Drawing.Point(159, 125);
            this.txtNome.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(287, 30);
            this.txtNome.TabIndex = 8;
            // 
            // txtSalHora
            // 
            this.txtSalHora.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalHora.Location = new System.Drawing.Point(269, 179);
            this.txtSalHora.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSalHora.Name = "txtSalHora";
            this.txtSalHora.Size = new System.Drawing.Size(132, 30);
            this.txtSalHora.TabIndex = 9;
            // 
            // txtNumHora
            // 
            this.txtNumHora.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumHora.Location = new System.Drawing.Point(269, 243);
            this.txtNumHora.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNumHora.Name = "txtNumHora";
            this.txtNumHora.Size = new System.Drawing.Size(132, 30);
            this.txtNumHora.TabIndex = 10;
            // 
            // txtDataEntEmp
            // 
            this.txtDataEntEmp.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDataEntEmp.Location = new System.Drawing.Point(375, 304);
            this.txtDataEntEmp.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDataEntEmp.Name = "txtDataEntEmp";
            this.txtDataEntEmp.Size = new System.Drawing.Size(132, 30);
            this.txtDataEntEmp.TabIndex = 11;
            // 
            // txtDiasFaltas
            // 
            this.txtDiasFaltas.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiasFaltas.Location = new System.Drawing.Point(239, 362);
            this.txtDiasFaltas.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDiasFaltas.Name = "txtDiasFaltas";
            this.txtDiasFaltas.Size = new System.Drawing.Size(132, 30);
            this.txtDiasFaltas.TabIndex = 12;
            // 
            // gbxTrabHomeOf
            // 
            this.gbxTrabHomeOf.Controls.Add(this.rbntNao);
            this.gbxTrabHomeOf.Controls.Add(this.rbtnSim);
            this.gbxTrabHomeOf.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbxTrabHomeOf.Location = new System.Drawing.Point(648, 126);
            this.gbxTrabHomeOf.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbxTrabHomeOf.Name = "gbxTrabHomeOf";
            this.gbxTrabHomeOf.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbxTrabHomeOf.Size = new System.Drawing.Size(381, 181);
            this.gbxTrabHomeOf.TabIndex = 13;
            this.gbxTrabHomeOf.TabStop = false;
            this.gbxTrabHomeOf.Text = "Trabalha em Home Office";
            // 
            // rbntNao
            // 
            this.rbntNao.AutoSize = true;
            this.rbntNao.Checked = true;
            this.rbntNao.Location = new System.Drawing.Point(20, 101);
            this.rbntNao.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbntNao.Name = "rbntNao";
            this.rbntNao.Size = new System.Drawing.Size(79, 33);
            this.rbntNao.TabIndex = 1;
            this.rbntNao.TabStop = true;
            this.rbntNao.Text = "Não";
            this.rbntNao.UseVisualStyleBackColor = true;
            // 
            // rbtnSim
            // 
            this.rbtnSim.AutoSize = true;
            this.rbtnSim.Location = new System.Drawing.Point(20, 48);
            this.rbtnSim.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnSim.Name = "rbtnSim";
            this.rbtnSim.Size = new System.Drawing.Size(78, 33);
            this.rbtnSim.TabIndex = 0;
            this.rbtnSim.TabStop = true;
            this.rbtnSim.Text = "Sim";
            this.rbtnSim.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(388, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(266, 40);
            this.label1.TabIndex = 14;
            this.label1.Text = "Cálculo Horista";
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1054, 496);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.gbxTrabHomeOf);
            this.Controls.Add(this.txtDiasFaltas);
            this.Controls.Add(this.txtDataEntEmp);
            this.Controls.Add(this.txtNumHora);
            this.Controls.Add(this.txtSalHora);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.lblDiasFalta);
            this.Controls.Add(this.lblDataEntEmp);
            this.Controls.Add(this.lblNumHoras);
            this.Controls.Add(this.lblSalHora);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Controls.Add(this.bntInstHor);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.gbxTrabHomeOf.ResumeLayout(false);
            this.gbxTrabHomeOf.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bntInstHor;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalHora;
        private System.Windows.Forms.Label lblNumHoras;
        private System.Windows.Forms.Label lblDataEntEmp;
        private System.Windows.Forms.Label lblDiasFalta;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalHora;
        private System.Windows.Forms.TextBox txtNumHora;
        private System.Windows.Forms.TextBox txtDataEntEmp;
        private System.Windows.Forms.TextBox txtDiasFaltas;
        private System.Windows.Forms.GroupBox gbxTrabHomeOf;
        private System.Windows.Forms.RadioButton rbntNao;
        private System.Windows.Forms.RadioButton rbtnSim;
        private System.Windows.Forms.Label label1;
    }
}