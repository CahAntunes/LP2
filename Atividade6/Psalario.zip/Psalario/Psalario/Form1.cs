﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDesconto_Click(object sender, EventArgs e)
        {
            double descINSS = 0;
            double descIRPF = 0;
            double salFamilia = 0;
            double salLiqui = 0;
            int numFilho = 0;

            if (txtNome.Text == string.Empty)
            {
                MessageBox.Show("Favor digitar o nome!");
                return;
            }

            if (cbxNumFilhos.SelectedIndex < 0)
            {
                MessageBox.Show("Favor selecionar o número de filhos!");
                return;
            }
            else if (!int.TryParse(cbxNumFilhos.SelectedItem.ToString(), out numFilho))
            {
                MessageBox.Show("Favor selecionar um número de filhos válido!");
                return;
            }

            mskbxSalBruto.Text = mskbxSalBruto.Text.Replace(".", ",");
            if (mskbxSalBruto.Text.Replace(",", "").Replace("_", "").Trim() == string.Empty)
            {
                MessageBox.Show("Favor digitar o salário!");
                return;
            }
            else
            {
                if (!double.TryParse(mskbxSalBruto.Text, out double salBruto))
                {
                    MessageBox.Show("Favor digitar apenas números para o salário!");
                    return;
                }
                else
                {
                    if (salBruto <= 0)
                    {
                        MessageBox.Show("Favor digitar um valor de salário maior que zero!");
                        return;
                    }
                    else
                    {
                        if (salBruto <= 800.47)
                        {
                            txtINSS.Text = "7.65%";
                            descINSS = salBruto * 0.0765;
                        }
                        else if (salBruto <= 1050)
                        {
                            txtINSS.Text = "8.65%";
                            descINSS = salBruto * 0.0865;
                        }
                        else if (salBruto <= 1400.77)
                        {
                            txtINSS.Text = "9%";
                            descINSS = salBruto * 0.09;
                        }
                        else if (salBruto <= 2801.56)
                        {
                            txtINSS.Text = "11%";
                            descINSS = salBruto * 0.11;
                        }
                        else
                        {
                            txtINSS.Text = "R$ 308.17";
                            descINSS = 308.17;
                        }

                        if (salBruto <= 1257.12)
                        {
                            txtIRPF.Text = "Isento";
                            descIRPF = 0;
                        }
                        else if (salBruto <= 2512.08)
                        {
                            txtIRPF.Text = "15%";
                            descIRPF = salBruto * 0.15;
                        }
                        else 
                        {
                            txtIRPF.Text = "27.5%";
                            descIRPF = salBruto * 0.275;
                        }

                        if (salBruto <= 435.52) 
                        {
                            salFamilia = numFilho * 22.33;
                        }
                        else if (salBruto <= 654.61)
                        {
                            salFamilia = numFilho * 15.74;
                        }
                        else
                        {
                            salFamilia = 0;
                        }
                        salLiqui = salBruto - descINSS - descIRPF + salFamilia;

                        txtSalFamilia.Text = "R$" + salFamilia.ToString("N2");
                        txtDescINSS.Text = "R$" + descINSS.ToString("N2");
                        txtDescIRPF.Text = "R$" + descIRPF.ToString("N2");
                        txtSalLiquido.Text = "R$" + salLiqui.ToString("N2");

                        lblDados.Text = "Os descontos do salário " +
                            (rbtnF.Checked ? "da Sra " : "do Sr ") +
                            txtNome.Text + 
                            (rbtnCasado.Checked ? " que é Casado(a) " : " que é Solteiro(a) ") +
                            ("e que tem: " + numFilho.ToString() + " filho(s)"); 
                    }   
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Clear();
            mskbxSalBruto.Clear();
            cbxNumFilhos.SelectedIndex = -1;
            rbtnF.Checked = true;
            rbtnCasado.Checked = false;
            txtDescINSS.Clear();
            txtDescIRPF.Clear();
            txtSalFamilia.Clear();
            txtSalLiquido.Clear();
            txtINSS.Clear();
            txtIRPF.Clear();
            lblDados.Text = string.Empty;
        }
    }
}
