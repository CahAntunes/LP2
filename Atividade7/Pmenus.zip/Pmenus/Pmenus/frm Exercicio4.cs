﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenus
{
    public partial class frm_Exercicio4 : Form
    {
        public frm_Exercicio4()
        {
            InitializeComponent();
        }

        private void btnNumero_Click(object sender, EventArgs e)
        {
            char[] texto = rchtxtTexto.Text.ToCharArray();
            int total = 0;

            for (int cont = 0; cont < texto.Length; cont++)
            {
                char caracter = texto[cont];

                if (char.IsNumber(caracter))
                {
                    total += 1;
                }
            }

            MessageBox.Show("O campo contém " + total + " número(s)!");
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            char[] texto = rchtxtTexto.Text.ToCharArray();
            int cont = 0;

            while(cont < texto.Length)
            {
                char caracter = texto[cont];

                if (char.IsWhiteSpace(caracter))
                {
                    break;
                }

                cont++;
            }

            MessageBox.Show("O primeiro caracter em branco está na posição " + (cont + 1) + "!");
        }

        private void btnLetras_Click(object sender, EventArgs e)
        {
            char[] texto = rchtxtTexto.Text.ToCharArray();
            int total = 0;

            foreach(char caracter in texto)
            {
                if (char.IsLetter(caracter))
                {
                    total += 1;
                }
            }

            MessageBox.Show("Existem " + total + " caracteres alfabéticos no campo!");
        }
    }
}
