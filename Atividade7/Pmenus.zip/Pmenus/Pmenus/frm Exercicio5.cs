﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenus
{
    public partial class frm_Exercicio5 : Form
    {
        public frm_Exercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            double numero1, numero2, escolhido;
            
            if (double.TryParse(txtNumero1.Text, out double resultado))
            {
                numero1 = resultado;
            }
            else
            {
                MessageBox.Show("O valor do Número 1 deve ser numérico!");
                return;
            }

            if (double.TryParse(txtNumero2.Text, out resultado))
            {
                numero2 = resultado;
            }
            else
            {
                MessageBox.Show("O valor do Número 2 deve ser numérico!");
                return;
            }

            Random random = new Random();
            var numeros = new[] { numero1, numero2 };

            escolhido = numeros[random.Next(numeros.Length)];
            
            MessageBox.Show("O número sorteado foi: " + escolhido + "!");
        }
    }
}
