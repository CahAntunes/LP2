﻿namespace Pmatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLer = new System.Windows.Forms.Button();
            this.btnarrayList = new System.Windows.Forms.Button();
            this.btnMercadorias = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.btnVariavel = new System.Windows.Forms.Button();
            this.btnNomes = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnLer
            // 
            this.btnLer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLer.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnLer.Location = new System.Drawing.Point(35, 30);
            this.btnLer.Margin = new System.Windows.Forms.Padding(4);
            this.btnLer.Name = "btnLer";
            this.btnLer.Size = new System.Drawing.Size(145, 66);
            this.btnLer.TabIndex = 0;
            this.btnLer.Text = "Ler 20 números e inverter";
            this.btnLer.UseVisualStyleBackColor = true;
            this.btnLer.Click += new System.EventHandler(this.btnLer_Click);
            // 
            // btnarrayList
            // 
            this.btnarrayList.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnarrayList.Location = new System.Drawing.Point(422, 132);
            this.btnarrayList.Margin = new System.Windows.Forms.Padding(4);
            this.btnarrayList.Name = "btnarrayList";
            this.btnarrayList.Size = new System.Drawing.Size(145, 50);
            this.btnarrayList.TabIndex = 1;
            this.btnarrayList.Text = "ArrayList";
            this.btnarrayList.UseVisualStyleBackColor = true;
            this.btnarrayList.Click += new System.EventHandler(this.btnarrayList_Click);
            // 
            // btnMercadorias
            // 
            this.btnMercadorias.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnMercadorias.Location = new System.Drawing.Point(227, 30);
            this.btnMercadorias.Margin = new System.Windows.Forms.Padding(4);
            this.btnMercadorias.Name = "btnMercadorias";
            this.btnMercadorias.Size = new System.Drawing.Size(147, 66);
            this.btnMercadorias.TabIndex = 2;
            this.btnMercadorias.Text = "Ler Quant. e Preço Mercadorias";
            this.btnMercadorias.UseVisualStyleBackColor = true;
            this.btnMercadorias.Click += new System.EventHandler(this.btnMercadorias_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnMedia.Location = new System.Drawing.Point(227, 132);
            this.btnMedia.Margin = new System.Windows.Forms.Padding(4);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(145, 50);
            this.btnMedia.TabIndex = 3;
            this.btnMedia.Text = "Média Alunos";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // btnVariavel
            // 
            this.btnVariavel.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnVariavel.Location = new System.Drawing.Point(427, 30);
            this.btnVariavel.Margin = new System.Windows.Forms.Padding(4);
            this.btnVariavel.Name = "btnVariavel";
            this.btnVariavel.Size = new System.Drawing.Size(140, 66);
            this.btnVariavel.TabIndex = 4;
            this.btnVariavel.Text = "Variável Total";
            this.btnVariavel.UseVisualStyleBackColor = true;
            this.btnVariavel.Click += new System.EventHandler(this.btnVariavel_Click);
            // 
            // btnNomes
            // 
            this.btnNomes.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnNomes.Location = new System.Drawing.Point(35, 130);
            this.btnNomes.Margin = new System.Windows.Forms.Padding(4);
            this.btnNomes.Name = "btnNomes";
            this.btnNomes.Size = new System.Drawing.Size(140, 52);
            this.btnNomes.TabIndex = 5;
            this.btnNomes.Text = "Nomes Pessoas";
            this.btnNomes.UseVisualStyleBackColor = true;
            this.btnNomes.Click += new System.EventHandler(this.btnNomes_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 233);
            this.Controls.Add(this.btnNomes);
            this.Controls.Add(this.btnVariavel);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnMercadorias);
            this.Controls.Add(this.btnarrayList);
            this.Controls.Add(this.btnLer);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnLer;
        private System.Windows.Forms.Button btnarrayList;
        private System.Windows.Forms.Button btnMercadorias;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Button btnVariavel;
        private System.Windows.Forms.Button btnNomes;
    }
}

