﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLer_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string saida = "0", aux;

            for (var i = 0; i < 20; i++)
            {
                aux = Interaction.InputBox("Digite número", "Entrada de dados");

                if (!Int32.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Dado inválido!");
                    i--;
                }
                else
                {
                    saida = vetor[i] + "\n" + saida;
                }
            }

            aux = " ";
            for (var i = 19; i >= 0; i--)
            {
                aux = aux + vetor[i] + "\n";
            }

            MessageBox.Show(aux);
        }

        private void btnMercadorias_Click(object sender, EventArgs e)
        {
            double[] qtde = new double[10];
            double[] vlr = new double[10];
            double faturamento = 0;
            string aux = " ";

            for (int i = 0; i < 10; i++)
            {
                aux = Interaction.InputBox("Digite a quantidade da mercadoria " + (i + 1), "Entrada de Quantidade");

                if (!double.TryParse(aux, out qtde[i]))
                {
                    MessageBox.Show("Quantidade inválida!");
                    i--;
                }
                else
                {
                    while (vlr[i] <= 0)
                    {
                        aux = " ";
                        aux = Interaction.InputBox("Digite o valor da mercadoria " + (i + 1), "Entrada de Preço");
                        
                        if (!double.TryParse(aux, out vlr[i]))
                        {
                            MessageBox.Show("Preço inválido!");
                        }
                    }
                }

                faturamento += qtde[i] * vlr[i];
            }

            MessageBox.Show(faturamento.ToString("N2"));
        }

        private void btnVariavel_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "Junior",  "Leonardo", "Jose", "Nelma", "Tobby" };
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show(Total.ToString());
        }

        private void btnNomes_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList() { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
            string aux = "";

            alunos.Remove("Otávio");

            foreach(var aluno in alunos)
            {
                aux += aluno.ToString() + ", ";
            }

            aux = aux.Substring(0, aux.Length - 2);
            MessageBox.Show(aux);
        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string aux;

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    aux = Interaction.InputBox("Digite a nota " + (j + 1) + " do aluno " + (i + 1), "Entrada de dados");

                    if (!double.TryParse(aux, out notas[i, j]))
                    {
                        MessageBox.Show("Quantidade inválida!");
                        i--;
                    }
                    else
                    {
                        if (!(notas[i, j] >= 0 && notas[i, j] <= 10))
                        {
                            MessageBox.Show("Nota inválida!");
                            j--;
                        }
                    }
                }

                double media = (notas[i, 0] + notas[i, 1] + notas[i, 2]) / 3;
                MessageBox.Show("Aluno " + (i + 1) + ": média " + media.ToString("N1"));
            }

        }

        private void btnarrayList_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["Form6"];
            if (fc != null)
                fc.Close();

            Form6 frm6 = new Form6();
            frm6.WindowState = FormWindowState.Normal;
            frm6.Show();
        }
    }
}
