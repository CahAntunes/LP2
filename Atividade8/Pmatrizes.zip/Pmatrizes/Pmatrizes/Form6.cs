﻿using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            lstbResultado.Items.Clear();

            //ultimo digito do RA = 7
            string[] nomes = new string[7];
            int[] tamanhoNomes = new int[7];
            string aux = "";

            for (int cont = 0; cont < 7; cont++)
            {
                aux = Interaction.InputBox("Digite o nome " + (cont + 1), "Entrada de Nomes");

                nomes[cont] = aux;
                char[] nome = aux.ToCharArray();

                tamanhoNomes[cont] = 0;
                foreach (char caracter in nome)
                {
                    if (!char.IsWhiteSpace(caracter))
                    {
                        tamanhoNomes[cont] += 1;
                    }
                }

                lstbResultado.Items.Add("Nome: " + nomes[cont] + " tem " + tamanhoNomes[cont].ToString() + " caracteres");
            }
        }
    }
}
