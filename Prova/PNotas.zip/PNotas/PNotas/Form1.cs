﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PNotas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            //final do RA = 7
            int aluno = 7, questao = 10;
            double[,] respostas = new double[aluno, questao];
            string[] gabarito = new string[10] { "A", "B", "C", "D", "E", "A", "B", "C", "D", "E" };
            bool valorInvalido = true;
            string aux;

            for (int l = 0; l < aluno; l++)
            {
                for (int c = 0; c < questao; c++)
                {
                    do
                    {
                        aux = Interaction.InputBox("Digite a resposta " + (c + 1) + " do aluno " + (l + 1), "Entrada de dados");
                        if ((aux == "A") || (aux == "B") || (aux == "C") || (aux == "D") || (aux == "E"))
                        {
                            valorInvalido = false;
                        }
                        else
                        {
                            valorInvalido = true;
                            MessageBox.Show("Valor inválido, insira novo valor!");
                        }

                    } while (valorInvalido);

                    if (aux == gabarito[c])
                    {
                        lstbResultado.Items.Add("O aluno: " + (l + 1) + " acertou questão: " + (c + 1) + " era " + gabarito[c] + " escolheu " + aux);
                    }
                    else
                    {
                        lstbResultado.Items.Add("O aluno: " + (l + 1) + " errou questão: " + (c + 1) + " era " + gabarito[c] + " escolheu " + aux);
                    }
                }
            }
        
        }
    }
}
